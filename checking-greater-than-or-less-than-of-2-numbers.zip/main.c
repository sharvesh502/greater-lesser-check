// Done by Sharvesh on 11.09.2025

#include <stdio.h>

void main()

{
    int a;
    printf("Enter the first Number:");
    scanf("%d",&a);
    int b;
    printf("Enter the second Number:");
    scanf("%d",&b);
    
    if (a>b)
    {
        printf("Checking whether the first number is greater than second number and the answer is\n");
        printf("True");
         
    }
    else
    {
        printf("Checking whether the first number is greater than second number and the answer is\n");
        printf("False");
    }
}